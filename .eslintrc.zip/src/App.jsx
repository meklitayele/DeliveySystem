import Navbar from './components/Navbar';
import { createTheme, ThemeProvider } from '@mui/material/styles';
import CssBaseline from '@mui/material/CssBaseline';
import { Home } from './pages/Home';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Login from './pages/Login';
import Footer from './components/Footer';
import Signup from './pages/Signup';
import { AuthProvider } from './context/AuthContext';

const App = () => {
 const theme = createTheme({
  palette: {
    primary: {
      main: '#27296d', 
    },
  },
});
  return (
    <>
    <AuthProvider>
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <Router>
        <Navbar/>
        <Routes>
          <Route path='/' element={<Home />} />
          <Route path='/Home' element={<Home />} />
          <Route path='/pages/Login' element={<Login />} /> 
          <Route path='/Signup' element={<Signup />} /> 
        </Routes>
      </Router>
      <Footer/>
     </ThemeProvider>
     </AuthProvider>
    </>
  )
}
export default App


