
export const routes = [
  { name: "Home", link: "/" },
  { name: "About", link: "/about" },
  // { name: "path name", link: "link url" }, like this
];