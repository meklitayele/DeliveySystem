module.exports = {

    plugins: [
        require('flowbite/plugin')
    ],
    content: [
        "./node_modules/flowbite/**/*.js"
    ]
}